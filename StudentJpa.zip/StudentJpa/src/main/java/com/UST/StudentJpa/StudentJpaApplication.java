package com.UST.StudentJpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentJpaApplication.class, args);
	}

}
