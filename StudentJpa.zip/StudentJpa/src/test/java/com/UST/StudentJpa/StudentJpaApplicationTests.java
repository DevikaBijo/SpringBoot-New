package com.UST.StudentJpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
