package com.javatechie.jpastreamer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpastreamerApplicationTests {

	@Test
	void contextLoads() {
	}

}
