package com.javatechie.jpastreamer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpastreamerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpastreamerApplication.class, args);
	}

}
