# spring-boot-jpastreamer
Express JPA Queries as Java Streams

![JPAStreamer_table](https://user-images.githubusercontent.com/25712816/128547952-d59a6936-de3d-47f4-9ecd-188829c02e2b.PNG)
